<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Struk {{ $penjualan_sparepart->kode }}</title>
    <style>
        @page {
            size: 58mm auto !important;
            margin: 0 !important;
            padding: 0 !important;
        }

        * { 
            margin: 0 !important; 
            padding: 0 !important; 
            box-sizing: border-box !important; 
        }

        html {
            width: 58mm !important;
            overflow-x: hidden !important;
        }

        body {
            width: 100% !important;
            max-width: 58mm !important;
            font-family: 'Courier New', Courier, monospace;
            font-size: 11px;
            color: #000;
            line-height: 1.3;
            /* PADDING UNTUK SY 58A: 2.5mm kiri-kanan (sesuai hardware margin) */
            padding: 1mm 2.5mm !important; 
            overflow-x: hidden !important;
        }

        @media screen {
            body {
                margin: 20px auto !important;
                border: 1px dashed #ccc;
                box-shadow: 0 0 15px rgba(0,0,0,0.1);
            }
        }

        .text-center { text-align: center !important; }
        .text-right { text-align: right !important; }
        .bold { font-weight: bold !important; }
        .text-sm { font-size: 10px !important; }
        .text-xs { font-size: 9px !important; }
        .text-xl { font-size: 13px !important; }
        
        .divider { border-top: 1px dashed #000 !important; margin: 3px 0 !important; }
        .divider-double { border-top: 2px solid #000 !important; margin: 4px 0 !important; }
        .garis { height: 1px !important; background: #000 !important; margin: 3px 0 !important; }
        
        .row { 
            display: flex !important; 
            justify-content: space-between !important; 
            padding: 1px 0 !important; 
            width: 100% !important;
        }
        .row span:first-child {
            flex: 1 !important;
            padding-right: 2px !important;
            word-break: break-word !important;
        }
        .row span:last-child {
            text-align: right !important;
            word-break: break-word !important;
            max-width: 60% !important;
        }
        
        .section-title { 
            font-weight: bold !important; 
            text-align: center !important; 
            margin: 4px 0 !important; 
            font-size: 11px !important; 
            letter-spacing: 1px !important; 
        }
        
        .mt-2 { margin-top: 3px !important; }
        .mb-2 { margin-bottom: 3px !important; }
        .mt-4 { margin-top: 6px !important; }

        table.item-table {
            width: 100% !important;
            table-layout: fixed !important;
            border-collapse: collapse !important;
        }
        table.item-table td {
            vertical-align: top !important;
            padding: 1px 0 !important;
            word-break: break-word !important;
            overflow-wrap: break-word !important;
        }
        
        .item-name { font-weight: bold !important; width: 65% !important; }
        .item-price-col { width: 35% !important; text-align: right !important; }

        .grand-total { 
            font-weight: bold !important; 
            font-size: 12px !important; 
            border-top: 2px solid #000 !important; 
            padding-top: 3px !important; 
            margin-top: 3px !important; 
        }

        .footer-code {
            word-break: break-all !important;
            letter-spacing: 1px !important;
        }

        @media print {
            html, body {
                width: 58mm !important;
                max-width: 58mm !important;
                margin: 0 !important;
                padding: 1mm 2.5mm !important;
                border: none !important;
                box-shadow: none !important;
                overflow: hidden !important;
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }
            * {
                page-break-inside: avoid !important;
            }
        }
    </style>
</head>
<body>
    {{-- HEADER --}}
    <div class="text-center">
        <div class="text-xl bold">{{ $settings['nama_toko'] ?? 'NAMA TOKO' }}</div>
        @if(!empty($settings['alamat']))
        <div class="text-sm">{{ $settings['alamat'] }}</div>
        @endif
        @if(!empty($settings['telp']))
        <div class="text-sm">Telp: {{ $settings['telp'] }}</div>
        @endif
    </div>
    <div class="divider-double"></div>

    <div class="text-center section-title mt-2 mb-2">NOTA PENJUALAN</div>
    <div class="divider"></div>

    {{-- INFO TRANSAKSI --}}
    <div class="row"><span>No. Transaksi:</span><span class="bold">{{ $penjualan_sparepart->no_transaksi ?? $penjualan_sparepart->kode }}</span></div>
    <div class="row"><span>Tanggal:</span><span>{{ $penjualan_sparepart->tanggal?->format('d/m/Y') ?? now()->format('d/m/Y') }}</span></div>
    <div class="row"><span>Waktu:</span><span>{{ $penjualan_sparepart->created_at?->format('H:i') ?? now()->format('H:i') }}</span></div>
    @if(isset($penjualan_sparepart->user))
    <div class="row"><span>Kasir:</span><span>{{ $penjualan_sparepart->user->name }}</span></div>
    @endif
    <div class="garis"></div>

    {{-- PELANGGAN --}}
    @if(isset($penjualan_sparepart->pelanggan))
    <div class="section-title mt-2">PELANGGAN</div>
    <div class="row"><span>Nama:</span><span class="bold">{{ Str::limit($penjualan_sparepart->pelanggan->nama, 20) }}</span></div>
    <div class="row"><span>No. HP:</span><span>{{ $penjualan_sparepart->pelanggan->no_hp ?? '-' }}</span></div>
    <div class="garis"></div>
    @endif

    {{-- DAFTAR BARANG --}}
    <div class="section-title mt-2">DAFTAR BARANG</div>
    
    @foreach($allItems as $item)
    <div class="item-row">
        <table class="item-table">
            <tr>
                <td class="item-name">{{ $item->stok?->nama ?? $item->nama ?? 'Nama Barang' }}</td>
                <td class="item-price-col">
                    {{ $item->qty }}x <br>
                    @php 
                        $harga = (float) ($item->harga_satuan ?? ($item->total / max(1, $item->qty))); 
                    @endphp
                    Rp {{ number_format($harga, 0, ',', '.') }}
                </td>
            </tr>
            <tr>
                <td colspan="2" class="text-right" style="border-top: 1px dotted #999; padding-top: 2px;">
                    <span class="bold">Rp {{ number_format($item->total, 0, ',', '.') }}</span>
                </td>
            </tr>
        </table>
    </div>
    @endforeach

    <div class="divider"></div>

    {{-- RINCIAN BAYAR --}}
    <div class="section-title mt-2">RINCIAN BAYAR</div>
    <div class="row"><span>Total Item ({{ $allItems->count() }}):</span><span>Rp {{ number_format($totalKeseluruhan ?? 0, 0, ',', '.') }}</span></div>

    @if(isset($diskon) && $diskon > 0)
    <div class="row discount-row"><span>- Diskon:</span><span>- Rp {{ number_format($diskon, 0, ',', '.') }}</span></div>
    @endif

    <div class="grand-total row">
        <span>TOTAL BAYAR:</span>
        <span>Rp {{ number_format($totalSetelahDiskon ?? ($totalKeseluruhan - ($diskon ?? 0)), 0, ',', '.') }}</span>
    </div>

    <div class="garis"></div>
    <div class="row"><span>Metode Bayar:</span><span class="bold">{{ $penjualan_sparepart->metode_bayar ?? 'Cash' }}</span></div>

    @if(!empty($penjualan_sparepart->catatan))
    <div class="garis"></div>
    <div class="row"><span>Catatan:</span><span>{{ $penjualan_sparepart->catatan }}</span></div>
    @endif

    @if($penjualan_sparepart->status === 'Dibatalkan')
    <div class="divider-double"></div>
    <div class="text-center bold" style="font-size:12px; margin: 4px 0;">*** DIBATALKAN ***</div>
    @endif

    <div class="divider-double"></div>

    {{-- FOOTER --}}
    <div class="text-center text-sm mt-4">
        <div>Terima kasih atas kunjungan Anda!</div>
        <div class="bold mt-2">{{ $settings['nama_toko'] ?? 'NAMA TOKO' }}</div>
    </div>

    <div class="text-center text-xs mt-4 footer-code">
        || {{ $penjualan_sparepart->kode }} ||
    </div>

    <div class="text-center text-xs mt-2" style="color:#333">
        Dicetak: {{ now()->format('d/m/Y H:i') }}
    </div>

    <script>
        (function() {
            if (window.hasPrinted) return; 
            window.hasPrinted = true;
            window.addEventListener('load', function() {
                setTimeout(function() { window.print(); }, 500); 
            });
        })();
    </script>
</body>
</html>