@extends('layouts.app')
@section('title', 'Detail Pembelian')

@section('content')
<a href="{{ route('pembelian.index') }}" class="btn btn-secondary btn-sm mb-3"><i class="fas fa-arrow-left"></i> Kembali</a>

<div style="display:grid;grid-template-columns:2fr 1fr;gap:16px" class="grid-responsive">
    <div class="card mb-4">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:8px;margin-bottom:16px">
            <div>
                <h2 style="margin:0;font-size:1.3rem"><strong style="color:var(--primary)">{{ $pembelian->kode }}</strong></h2>
                <div style="font-size:.82rem;color:#64748b;margin-top:2px">
                    {{ $pembelian->tanggal?->format('d/m/Y') }} • oleh {{ $pembelian->user?->name ?? '-' }}
                </div>
            </div>
            @php $badgeColor = ['Belum Dibayar'=>'#fee2e2|dc2626','Sebagian'=>'#fef3c7|b45309','Lunas'=>'#dcfce7|16a34a','Dibatalkan'=>'#f1f5f9|64748b'][$pembelian->status] ?? '#f1f5f9|64748b'; @endphp
            <span style="background:{{ explode('|',$badgeColor)[0] }};color:{{ explode('|',$badgeColor)[1] }};padding:4px 12px;border-radius:12px;font-size:.78rem;font-weight:700">{{ $pembelian->status }}</span>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:18px;font-size:.84rem">
            <div>
                <div style="color:#94a3b8;font-size:.72rem;font-weight:600;text-transform:uppercase;margin-bottom:2px">Supplier</div>
                <div style="font-weight:600">{{ $pembelian->supplier_nama }}</div>
                @if($pembelian->supplier_kontak)<div style="color:#64748b"><i class="fas fa-phone" style="font-size:.7rem"></i> {{ $pembelian->supplier_kontak }}</div>@endif
                @if($pembelian->supplier_alamat)<div style="color:#64748b;font-size:.78rem">{{ $pembelian->supplier_alamat }}</div>@endif
            </div>
            <div>
                @if($pembelian->tanggal_jatuh_tempo)
                <div style="color:#94a3b8;font-size:.72rem;font-weight:600;text-transform:uppercase;margin-bottom:2px">Jatuh Tempo</div>
                <div style="font-weight:600;color:{{ $pembelian->sisa > 0 && $pembelian->tanggal_jatuh_tempo->isPast() ? '#dc2626' : '#0f172a' }}">{{ $pembelian->tanggal_jatuh_tempo->format('d/m/Y') }}</div>
                @endif
                <div style="color:#94a3b8;font-size:.72rem;font-weight:600;text-transform:uppercase;margin-top:6px;margin-bottom:2px">Metode</div>
                <div>{{ $pembelian->metode_bayar }}</div>
            </div>
        </div>

        @if($pembelian->catatan)
        <div style="background:#f8fafc;border-radius:8px;padding:10px 14px;margin-bottom:16px;font-size:.8rem;color:#475569;border-left:3px solid var(--primary)">
            <i class="fas fa-sticky-note"></i> {{ $pembelian->catatan }}
        </div>
        @endif

        <div class="table-wrap">
            <table>
                <thead><tr><th>Barang</th><th>Kode</th><th>Qty</th><th>Harga Beli</th><th>Harga Jual</th><th>Subtotal</th></tr></thead>
                <tbody>
                    @foreach(($pembelian->items ?? []) as $it)
                    <tr>
                        <td>{{ $it['nama'] }}</td>
                        <td style="font-size:.78rem;color:#64748b">{{ $it['kode'] ?? '-' }}</td>
                        <td style="text-align:center">{{ $it['qty'] }}</td>
                        <td>{{ formatRp($it['harga_beli']) }}</td>
                        <td>{{ formatRp($it['harga_jual'] ?? 0) }}</td>
                        <td style="font-weight:600">{{ formatRp($it['subtotal']) }}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>

        <div style="display:flex;justify-content:flex-end;margin-top:16px">
            <div style="width:280px;font-size:.86rem">
                <div style="display:flex;justify-content:space-between;margin-bottom:6px"><span>Subtotal</span><strong>{{ formatRp($pembelian->subtotal) }}</strong></div>
                <div style="display:flex;justify-content:space-between;color:#dc2626;margin-bottom:6px"><span>Diskon ({{ $pembelian->diskon_persen }}% + {{ formatRp($pembelian->diskon_nominal) }})</span><strong>- {{ formatRp($pembelian->subtotal - $pembelian->total) }}</strong></div>
                <div style="display:flex;justify-content:space-between;padding-top:8px;border-top:2px solid #e2e8f0;margin-bottom:6px;font-size:1rem"><strong>Total</strong><strong style="color:var(--primary)">{{ formatRp($pembelian->total) }}</strong></div>
                <div style="display:flex;justify-content:space-between;margin-bottom:6px;color:#16a34a"><span>Dibayar</span><strong>{{ formatRp($pembelian->dibayar) }}</strong></div>
                <div style="display:flex;justify-content:space-between;color:#dc2626;font-weight:700"><span>Sisa Hutang</span><strong>{{ formatRp($pembelian->sisa) }}</strong></div>
            </div>
        </div>
    </div>

    <div>
        @if($pembelian->status !== 'Dibatalkan' && $pembelian->sisa > 0)
        <div class="card mb-4">
            <h3 style="font-size:.92rem;margin-bottom:14px"><i class="fas fa-hand-holding-usd" style="color:#dc2626"></i> Bayar Hutang</h3>
            <form method="POST" action="{{ route('pembelian.bayar-hutang', $pembelian) }}">
                @csrf
                <div class="form-group">
                    <label>Jumlah Bayar (maks {{ formatRp($pembelian->sisa) }})</label>
                    <input type="number" name="jumlah" class="form-input" min="1" max="{{ $pembelian->sisa }}" step="1000" required>
                </div>
                <div class="form-group">
                    <label>Metode</label>
                    <select name="metode" class="form-input">
                        @foreach(['Cash','Transfer','QRIS'] as $m)<option value="{{ $m }}">{{ $m }}</option>@endforeach
                    </select>
                </div>
                <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-check"></i> Bayar</button>
            </form>
        </div>
        @endif

        @if($pembelian->status !== 'Dibatalkan')
        <div class="card mb-4">
            <h3 style="font-size:.92rem;margin-bottom:14px"><i class="fas fa-undo" style="color:#d97706"></i> Retur Barang</h3>
            <div style="font-size:.74rem;color:#64748b;margin-bottom:10px">Kembalikan barang ke supplier. Stok berkurang, kas kembali (refund).</div>
            <form method="POST" action="{{ route('pembelian.retur', $pembelian) }}">
                @csrf
                <div class="form-group">
                    <label>Pilih Barang</label>
                    <select name="stok_id" class="form-input" required>
                        <option value="">-- Pilih --</option>
                        @foreach(($pembelian->items ?? []) as $it)
                        @if(!empty($it['stok_id']))
                        <option value="{{ $it['stok_id'] }}">{{ $it['nama'] }} — beli {{ formatRp($it['harga_beli']) }} (x{{ $it['qty'] }})</option>
                        @endif
                        @endforeach
                    </select>
                </div>
                <div class="form-group">
                    <label>Qty Retur</label>
                    <input type="number" name="qty" class="form-input" min="1" required value="1">
                </div>
                <div class="form-group">
                    <label>Alasan (opsional)</label>
                    <input type="text" name="alasan" class="form-input" placeholder="Rusak / salah item / dll">
                </div>
                <button type="submit" class="btn btn-warning btn-sm" style="background:#d97706;color:#fff"><i class="fas fa-undo"></i> Retur</button>
            </form>
        </div>

        @if($pembelian->status !== 'Dibatalkan')
        <div class="card mb-4" style="border-color:#fecaca">
            <h3 style="font-size:.92rem;margin-bottom:14px;color:#dc2626"><i class="fas fa-ban"></i> Batalkan Pembelian</h3>
            <div style="font-size:.74rem;color:#64748b;margin-bottom:10px">Mengembalikan seluruh stok & kas yang sudah dibayar. Tidak dapat dibatalkan jika sebagian barang sudah terjual.</div>
            <details>
                <summary style="cursor:pointer;font-size:.8rem;color:#dc2626;font-weight:600">Buka form pembatalan</summary>
                <form method="POST" action="{{ route('pembelian.batal', $pembelian) }}" style="margin-top:10px">
                    @csrf
                    <div class="form-group">
                        <label>Alasan *</label>
                        <input type="text" name="alasan" class="form-input" required minlength="3">
                    </div>
                    <button type="submit" class="btn btn-danger btn-sm" style="background:#dc2626;color:#fff" onclick="return confirm('Yakin batalkan? Stok & kas akan dikembalikan.')"><i class="fas fa-ban"></i> Batalkan</button>
                </form>
            </details>
        </div>
        @endif
        @endif
    </div>
</div>

<style>
@media (max-width: 768px) { .grid-responsive { grid-template-columns: 1fr !important; } }
</style>
@endsection
