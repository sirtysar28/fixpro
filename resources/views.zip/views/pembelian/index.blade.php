@extends('layouts.app')
@section('title', 'Pembelian Supplier')

@section('content')
<h2 class="mb-4"><i class="fas fa-truck-loading" style="color:var(--primary);margin-right:6px"></i>Pembelian Supplier</h2>

<div class="stats-grid mb-4">
    <div class="stat-card">
        <div class="stat-icon" style="background:#fef3c7;color:#d97706"><i class="fas fa-shopping-bag"></i></div>
        <div class="stat-label">Total Pembelian</div>
        <div class="stat-value" style="color:#d97706">{{ formatRp($totalPembelian) }}</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:#fee2e2;color:#dc2626"><i class="fas fa-hand-holding-usd"></i></div>
        <div class="stat-label">Total Hutang Supplier</div>
        <div class="stat-value" style="color:#dc2626">{{ formatRp($totalHutang) }}</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:var(--primary-bg);color:var(--primary)"><i class="fas fa-receipt"></i></div>
        <div class="stat-label">Total Transaksi</div>
        <div class="stat-value" style="color:var(--primary)">{{ $totalTransaksi }}</div>
    </div>
</div>

@if($jatuhTempo->count() > 0)
<div style="background:linear-gradient(135deg,#fef3c7,#fde68a);border:1px solid #fcd34d;border-radius:12px;padding:14px 18px;margin-bottom:16px;display:flex;align-items:center;gap:10px">
    <i class="fas fa-exclamation-triangle" style="color:#b45309;font-size:1.2rem"></i>
    <div style="font-size:.82rem;color:#78350f">
        <strong>{{ $jatuhTempo->count() }} hutang jatuh tempo dalam 7 hari:</strong>
        @foreach($jatuhTempo->take(3) as $jt)
        <span style="margin-left:6px">{{ $jt->kode }} ({{ $jt->supplier_nama }}) — Rp {{ number_format($jt->sisa,0,',','.') }} @if($jt->tanggal_jatuh_tempo)<em style="opacity:.7">({{ $jt->tanggal_jatuh_tempo->format('d/m/Y') }})</em>@endif</span>{{ !$loop->last ? '•' : '' }}
        @endforeach
    </div>
</div>
@endif

<div class="card mb-4">
    <form method="GET" style="display:flex;gap:8px;flex-wrap:wrap;align-items:flex-end">
        <div class="form-group" style="margin:0;flex:1;min-width:160px">
            <label class="text-xs font-bold text-muted">Cari (kode/supplier)</label>
            <input type="text" name="search" class="form-input" value="{{ request('search') }}" placeholder="Kode / nama supplier..." style="padding:8px 12px;font-size:.84rem">
        </div>
        <div class="form-group" style="margin:0">
            <label class="text-xs font-bold text-muted">Status</label>
            <select name="status" class="form-input" style="padding:8px 12px;font-size:.84rem">
                <option value="">Semua</option>
                @foreach(['Belum Dibayar','Sebagian','Lunas','Dibatalkan'] as $st)
                <option value="{{ $st }}" {{ request('status') === $st ? 'selected' : '' }}>{{ $st }}</option>
                @endforeach
            </select>
        </div>
        <div class="form-group" style="margin:0">
            <label class="text-xs font-bold text-muted">Dari</label>
            <input type="date" name="dari" class="form-input" value="{{ request('dari') }}" style="padding:8px 12px;font-size:.84rem">
        </div>
        <div class="form-group" style="margin:0">
            <label class="text-xs font-bold text-muted">Sampai</label>
            <input type="date" name="sampai" class="form-input" value="{{ request('sampai') }}" style="padding:8px 12px;font-size:.84rem">
        </div>
        <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-filter"></i> Filter</button>
        <a href="{{ route('pembelian.create') }}" class="btn btn-success btn-sm" style="background:#16a34a;color:#fff"><i class="fas fa-plus"></i> Pembelian Baru</a>
    </form>
</div>

<div class="card">
    <div class="card-header">
        <h3 style="font-size:.95rem"><i class="fas fa-list"></i> Riwayat Pembelian</h3>
        <span class="text-muted text-sm">{{ $items->total() }} data</span>
    </div>
    <div class="table-wrap">
        <table>
            <thead><tr><th>Kode</th><th>Tgl</th><th>Supplier</th><th>Items</th><th>Total</th><th>Dibayar</th><th>Sisa (Hutang)</th><th>Status</th><th>Aksi</th></tr></thead>
            <tbody>
                @foreach($items as $p)
                <tr>
                    <td><strong style="color:var(--primary)">{{ $p->kode }}</strong></td>
                    <td>{{ $p->tanggal?->format('d/m/Y') }}</td>
                    <td>{{ $p->supplier_nama }}<br><span style="font-size:.7rem;color:#94a3b8">{{ $p->supplier_kontak }}</span></td>
                    <td style="text-align:center">{{ is_array($p->items) ? count($p->items) : 0 }}</td>
                    <td style="font-weight:600">{{ formatRp($p->total) }}</td>
                    <td>{{ formatRp($p->dibayar) }}</td>
                    <td style="color:{{ $p->sisa > 0 ? '#dc2626' : '#16a34a' }};font-weight:600">{{ formatRp($p->sisa) }}</td>
                    <td>
                        @php $badgeColor = ['Belum Dibayar'=>'#fee2e2|dc2626','Sebagian'=>'#fef3c7|b45309','Lunas'=>'#dcfce7|16a34a','Dibatalkan'=>'#f1f5f9|64748b'][$p->status] ?? '#f1f5f9|64748b'; @endphp
                        <span style="background:{{ explode('|',$badgeColor)[0] }};color:{{ explode('|',$badgeColor)[1] }};padding:2px 8px;border-radius:10px;font-size:.7rem;font-weight:700">{{ $p->status }}</span>
                    </td>
                    <td>
                        <a href="{{ route('pembelian.show', $p) }}" class="btn btn-primary btn-xs"><i class="fas fa-eye"></i></a>
                    </td>
                </tr>
                @endforeach
                @if($items->count() === 0)
                <tr><td colspan="9" style="text-align:center;color:#94a3b8;padding:24px">Belum ada pembelian. Klik "Pembelian Baru" untuk mulai.</td></tr>
                @endif
            </tbody>
        </table>
    </div>
    {{ $items->links() }}
</div>
@endsection
