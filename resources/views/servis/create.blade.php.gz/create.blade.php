@extends('layouts.app')
@section('title', 'Input Servis Baru')

@section('content')
<h2 style="margin-bottom:20px;font-size:1.3rem">Input Servis Baru</h2>

<div class="grid-2">
    <div class="card">
        <h3 style="font-size:.95rem;margin-bottom:16px"><i class="fas fa-keyboard" style="color:var(--primary);margin-right:6px"></i> Form Servis</h3>
        <form method="POST" action="{{ route('servis.store') }}" enctype="multipart/form-data">
            @csrf

            {{-- PILIH PELANGGAN --}}
            <div style="margin-bottom:20px;padding-bottom:16px;border-bottom:2px dashed #e2e8f0">
                <h3 style="font-size:.9rem;margin-bottom:12px;color:#334155">
                    <i class="fas fa-user-friends" style="color:var(--accent);margin-right:6px"></i> Data Pelanggan
                </h3>
                <div class="form-group">
                    <label>Pilih Pelanggan yang Sudah Terdaftar</label>
                    <select id="pelangganSelect" class="form-input" onchange="pilihPelanggan(this)">
                        <option value="">— Pilih Pelanggan / Input Manual —</option>
                        @foreach($pelanggans as $p)
                        <option value="{{ $p->id }}" data-nama="{{ $p->nama }}" data-no-hp="{{ $p->no_hp }}" data-alamat="{{ $p->alamat ?? '' }}" @if($p->user) data-user-email="{{ $p->user->email }}" @endif>
                            {{ $p->nama }} — {{ $p->no_hp }}
                        </option>
                        @endforeach
                    </select>
                    <div class="text-xs text-muted" style="margin-top:4px">Pilih pelanggan yang sudah ada, atau kosongkan lalu isi manual di bawah untuk pelanggan baru</div>
                </div>

                <div class="form-group">
                    <label>No. HP Pelanggan *</label>
                    <input type="tel" name="no_hp" class="form-input" id="noHp" placeholder="08xxx" required>
                </div>
                <div class="form-group">
                    <label>Nama Pelanggan *</label>
                    <input type="text" name="nama" class="form-input" id="namaP" placeholder="Nama pelanggan" required>
                </div>
                <div class="form-group">
                    <label>Alamat</label>
                    <input type="text" name="alamat" class="form-input" id="alamatP" placeholder="Alamat pelanggan">
                </div>
                <div id="infoPelanggan" style="display:none;padding:10px;border-radius:8px;background:#f0fdf4;border:1px solid #bbf7d0;font-size:.8rem;color:#166534;margin-bottom:8px">
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>Merk HP *</label>
                    <select id="merkHpSelect" class="form-input" onchange="loadTipeHp()">
                        <option value="">-- Pilih Merk / Ketik Manual --</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Tipe / Model HP *</label>
                    <select id="tipeHpSelect" class="form-input" onchange="autoFillPerangkat()">
                        <option value="">-- Pilih Merk dulu --</option>
                    </select>
                    <input type="text" id="perangkatInput" name="perangkat" class="form-input" placeholder="Atau ketik manual (contoh: iPhone 11)" required style="margin-top:6px">
                </div>
            </div>
            <div class="form-group">
                <label>Tipe OS *</label>
                <select name="tipe" class="form-input" required>
                    <option value="">-- Pilih --</option>
                    <option value="Apple">Apple (iOS)</option>
                    <option value="Android">Android</option>
                </select>
            </div>

            {{-- ===== IMEI & ESTIMASI (DENGAN ANTI AUTO-FILL) ===== --}}
            <div class="form-row">
                <div class="form-group">
                    <label>
                        <i class="fas fa-fingerprint" style="color:var(--primary);margin-right:4px"></i> IMEI
                    </label>
                    <input 
                        type="text" 
                        name="imei" 
                        id="imeiInput"
                        class="form-input" 
                        placeholder="15 digit angka" 
                        maxlength="15"
                        inputmode="numeric"
                        pattern="[0-9]*"
                        autocomplete="off"
                        autocapitalize="off"
                        autocorrect="off"
                        spellcheck="false"
                        data-lpignore="true"
                        data-form-type="other"
                        oninput="this.value = this.value.replace(/[^0-9]/g, '')"
                        style="font-family:'Courier New',monospace;letter-spacing:2px"
                    >
                    <div class="text-xs text-muted" style="margin-top:4px">
                        <i class="fas fa-info-circle" style="color:var(--info)"></i> 
                        Cek IMEI di HP: tekan <strong style="color:var(--primary)">*#06#</strong> dari dialer
                    </div>
                </div>
                <div class="form-group">
                    <label>Estimasi Selesai</label>
                    <input type="datetime-local" name="eta" class="form-input" autocomplete="off">
                </div>
            </div>

            {{-- ===== KEAMANAN PERANGKAT (POLA, PASSWORD, PIN) ===== --}}
            <div style="margin-top:16px;padding-top:16px;border-top:2px dashed #e2e8f0">
                <h3 style="font-size:.95rem;margin-bottom:12px">
                    <i class="fas fa-lock" style="color:#f59e0b;margin-right:6px"></i> Keamanan Perangkat
                </h3>
                <div class="text-xs text-muted" style="margin-bottom:12px;color:#64748b">
                    Isi pola / password / PIN agar teknisi dapat menguji perangkat setelah servis. <strong>Data ini bersifat rahasia</strong> dan tidak dikirim ke pelanggan.
                </div>

                <div class="form-row">
                    {{-- KOLOM POLA (Pattern Lock) --}}
                    <div class="form-group">
                        <label>
                            <i class="fas fa-th" style="color:var(--primary);margin-right:4px"></i> Pola Kunci (Pattern Lock)
                        </label>
                        <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:12px">
                            <div id="patternGrid" style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;max-width:220px;margin:0 auto">
                                {{-- 9 titik pola --}}
                                @for ($i = 1; $i <= 9; $i++)
                                <button type="button" class="pattern-dot" data-num="{{ $i }}" onclick="togglePatternDot(this)" style="
                                    aspect-ratio:1;
                                    border-radius:50%;
                                    border:2px solid #cbd5e1;
                                    background:#fff;
                                    cursor:pointer;
                                    font-weight:700;
                                    color:#64748b;
                                    font-size:.85rem;
                                    transition:all .2s;
                                    display:flex;align-items:center;justify-content:center;
                                ">{{ $i }}</button>
                                @endfor
                            </div>
                            <div style="margin-top:10px;display:flex;gap:6px;align-items:center">
                                <div style="flex:1;font-size:.78rem;color:#64748b;background:#fff;padding:6px 10px;border-radius:6px;border:1px solid #e2e8f0;min-height:28px;font-family:monospace;letter-spacing:2px" id="patternDisplay">
                                    — belum ada pola —
                                </div>
                                <button type="button" onclick="clearPattern()" class="btn btn-secondary btn-xs" title="Hapus pola"><i class="fas fa-undo"></i></button>
                            </div>
                            <input type="hidden" name="pola" id="polaInput" value="">
                        </div>
                    </div>

                    {{-- KOLOM PASSWORD & PIN (DENGAN ANTI AUTO-FILL) --}}
                    <div class="form-group">
                        <label>
                            <i class="fas fa-key" style="color:var(--accent);margin-right:4px"></i> Password / PIN
                        </label>
                        <div style="display:flex;flex-direction:column;gap:10px">
                            {{-- Password --}}
                            <div>
                                <label class="text-xs text-muted" style="margin-bottom:4px;display:block">Password (jika ada)</label>
                                <div style="position:relative">
                                    <input 
                                        type="password" 
                                        name="password_hp" 
                                        id="passwordInput" 
                                        class="form-input" 
                                        placeholder="Password layar kunci HP" 
                                        style="padding-right:40px"
                                        autocomplete="new-password"
                                        autocapitalize="off"
                                        autocorrect="off"
                                        spellcheck="false"
                                        data-lpignore="true"
                                        data-form-type="other"
                                    >
                                    <button type="button" onclick="togglePasswordVisibility('passwordInput', this)" style="position:absolute;right:10px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;color:#64748b;font-size:.9rem">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>

                            {{-- PIN --}}
                            <div>
                                <label class="text-xs text-muted" style="margin-bottom:4px;display:block">PIN (jika pakai PIN)</label>
                                <div style="position:relative">
                                    <input 
                                        type="password" 
                                        name="pin" 
                                        id="pinInput" 
                                        class="form-input" 
                                        placeholder="PIN layar kunci HP" 
                                        inputmode="numeric" 
                                        maxlength="10" 
                                        style="padding-right:40px"
                                        autocomplete="new-password"
                                        autocapitalize="off"
                                        autocorrect="off"
                                        spellcheck="false"
                                        data-lpignore="true"
                                        data-form-type="other"
                                        oninput="this.value = this.value.replace(/[^0-9]/g, '')"
                                    >
                                    <button type="button" onclick="togglePasswordVisibility('pinInput', this)" style="position:absolute;right:10px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;color:#64748b;font-size:.9rem">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>

                            {{-- Info keamanan --}}
                            <div style="background:#fefce8;border:1px solid #fde68a;border-radius:8px;padding:8px 10px;font-size:.75rem;color:#854d0e">
                                <i class="fas fa-shield-alt" style="margin-right:4px"></i>
                                <strong>Info Keamanan:</strong> Data ini tidak ikut dikirim ke WhatsApp pelanggan.
                            </div>

                            {{-- Tombol kirim ke WA Teknisi --}}
                            <button type="button" onclick="kirimKeTeknisi()" class="btn btn-secondary btn-sm" style="background:#fef3c7;color:#92400e;border:1px solid #fde68a">
                                <i class="fab fa-whatsapp" style="color:#25D366;margin-right:6px"></i> Kirim Data Keamanan ke WA Teknisi
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            {{-- ===== END KEAMANAN PERANGKAT ===== --}}

            <div class="form-group" style="position:relative;margin-top:16px">
                <label>Keluhan *</label>
                <input type="text" name="keluhan" class="form-input" id="keluhanInput" placeholder="Ganti LCD" required oninput="searchServicePrice(this.value)" onblur="setTimeout(()=>{document.getElementById('priceSuggestions').style.display='none'},300)">
                <div id="priceSuggestions" style="display:none;position:absolute;top:100%;left:0;right:0;background:#fff;border:1px solid #e2e8f0;border-radius:8px;box-shadow:0 8px 25px rgba(0,0,0,.12);z-index:100;max-height:250px;overflow-y:auto"></div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Biaya Servis (Total) (Rp)</label>
                    <input type="text" inputmode="numeric" name="biaya" id="biayaInput" class="form-input" value="0" min="0" data-format-rupiah>
                    <div class="text-xs text-muted" style="margin-top:4px;color:#64748b">Masukkan harga <strong>keseluruhan</strong> yang ditagihkan ke pelanggan (sudah termasuk jasa + sparepart). Sparepart di bawah hanya untuk tracking & laba.</div>
                </div>
                <div class="form-group">
                    <label>DP (Rp)</label>
                    <input type="text" inputmode="numeric" name="dp" id="dpInput" class="form-input" value="0" min="0" data-format-rupiah>
                </div>
            </div>

            {{-- Total Otomatis --}}
            <div id="totalBox" style="background:linear-gradient(135deg,#0d9488,#065f46);color:#fff;border-radius:12px;padding:16px 20px;margin-bottom:16px;display:flex;justify-content:space-between;align-items:center">
                <div>
                    <div style="font-size:.78rem;opacity:.85">Total yang harus dibayar</div>
                    <div style="font-size:.68rem;opacity:.7;margin-top:2px">Biaya Servis - DP</div>
                </div>
                <div style="font-size:1.3rem;font-weight:800" id="totalBayarDisplay">Rp 0</div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>Status</label>
                    <select name="status" class="form-input">
                        <option>Masuk</option><option>Proses</option><option>Pending</option><option>Selesai</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Prioritas</label>
                    <select name="prioritas" class="form-input">
                        <option>Normal</option><option>Urgent</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label>Teknisi</label>
                <select name="teknisi_id" id="teknisiSelect" class="form-input">
                    <option value="">-- Pilih Teknisi --</option>
                    @foreach($teknisis as $t)
                    <option value="{{ $t->id }}" @if($t->no_hp ?? false) data-no-hp="{{ $t->no_hp }}" @endif>{{ $t->nama }} ({{ $t->spesialisasi }})</option>
                    @endforeach
                </select>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Garansi (hari)</label>
                    <input type="number" name="garansi" class="form-input" value="30" min="0">
                </div>
                <div class="form-group">
                    <label>Catatan</label>
                    <input type="text" name="catatan" class="form-input" placeholder="Opsional">
                </div>
            </div>

            {{-- Sparepart Selection (Admin only) --}}
            @if(auth()->user()->isAdmin())
            <div style="margin-top:16px;padding-top:16px;border-top:1px solid #e2e8f0">
                <h3 style="font-size:.95rem;margin-bottom:12px"><i class="fas fa-puzzle-piece" style="color:var(--accent);margin-right:6px"></i> Sparepart Digunakan</h3>
                <div id="sparepartContainer">
                    <div class="sparepart-row" style="display:flex;gap:8px;align-items:flex-end;margin-bottom:8px">
                        <div style="flex:2">
                            <label class="text-xs font-bold text-muted">Pilih Sparepart</label>
                            <select name="sparepart_ids[]" class="form-input sparepart-select" onchange="updateSparepartPrice(this)">
                                <option value="">-- Pilih --</option>
                                @foreach($spareparts as $sp)
                                <option value="{{ $sp->id }}" data-harga="{{ $sp->jual }}" data-nama="{{ $sp->nama }}" data-stok="{{ $sp->stok }}">{{ $sp->nama }} (Stok: {{ $sp->stok }}) - {{ formatRp($sp->jual) }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div style="flex:0 0 70px">
                            <label class="text-xs font-bold text-muted">Qty</label>
                            <input type="number" name="sparepart_qtys[]" class="form-input sparepart-qty" value="1" min="1" style="text-align:center">
                        </div>
                        <div style="flex:1">
                            <label class="text-xs font-bold text-muted">Harga Jual</label>
                            <input type="text" inputmode="numeric" name="sparepart_prices[]" class="form-input sparepart-price" value="0" min="0" data-format-rupiah>
                        </div>
                        <button type="button" onclick="removeSparepartRow(this)" class="btn btn-danger btn-xs" style="margin-bottom:1px"><i class="fas fa-trash"></i></button>
                    </div>
                </div>
                <button type="button" onclick="addSparepartRow()" class="btn btn-secondary btn-sm"><i class="fas fa-plus"></i> Tambah Sparepart</button>
            </div>
            @endif
            @include('servis._sparepart-combobox')

            {{-- Foto Kondisi HP --}}
            <div style="margin-top:16px;padding-top:16px;border-top:1px solid #e2e8f0">
                <h3 style="font-size:.95rem;margin-bottom:12px"><i class="fas fa-camera" style="color:var(--info);margin-right:6px"></i> Foto Kondisi HP</h3>
                <div class="form-group">
                    <input type="file" name="foto[]" class="form-input" accept="image/*" multiple>
                    <div class="text-xs text-muted" style="margin-top:4px">Upload foto kondisi HP (bisa lebih dari 1)</div>
                </div>
                <div id="fotoPreview" style="display:flex;gap:8px;flex-wrap:wrap"></div>
            </div>

            {{-- AUTO KIRIM WA --}}
            <div style="margin-top:20px; padding:14px 16px; background:linear-gradient(135deg, #dcfce7, #f0fdf4); border:1px solid #bbf7d0; border-radius:10px;">
                <label style="display:flex; align-items:center; gap:12px; cursor:pointer; margin:0;">
                    <input type="checkbox" id="autoWaCheckbox" name="auto_wa" value="1" checked style="width:22px; height:22px; accent-color:#25D366; cursor:pointer;">
                    <div>
                        <div style="font-weight:700; color:#166534; font-size:.95rem; display:flex; align-items:center; gap:8px;">
                            <i class="fab fa-whatsapp" style="font-size:1.3rem; color:#25D366;"></i> Auto Kirim Nota via WhatsApp
                        </div>
                        <div class="text-xs" style="color:#15803d; margin-top:2px;">
                            Nota digital akan otomatis dibuka di WhatsApp Web / Aplikasi pelanggan saat Anda klik Simpan. <strong>(Data keamanan tidak ikut dikirim)</strong>
                        </div>
                    </div>
                </label>
            </div>

            <div class="form-group" style="margin-top:16px">
                <label>Kode Servis</label>
                <input type="text" id="kodeServis" class="form-input" value="{{ $nextKode }}" readonly style="background:#f8fafc;font-weight:700;color:var(--primary)">
            </div>
            <div style="display:flex;gap:8px;margin-top:20px">
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Simpan</button>
                <a href="{{ route('servis.index') }}" class="btn btn-secondary"><i class="fas fa-times"></i> Batal</a>
            </div>
        </form>
    </div>
    <div>
        <div class="card">
            <h3 style="font-size:.95rem;margin-bottom:10px"><i class="fas fa-bolt" style="color:var(--accent);margin-right:6px"></i>Fitur</h3>
            <ul style="font-size:.84rem;color:#64748b;line-height:2;padding-left:16px">
                <li><strong style="color:var(--primary)">Pilih pelanggan dari daftar</strong> atau input baru</li>
                <li>Pelanggan baru otomatis dapat akun user</li>
                <li>Auto-fill data dari No HP</li>
                <li>Tracking IMEI perangkat</li>
                <li>Estimasi waktu selesai (ETA)</li>
                <li><strong style="color:#f59e0b">🔒 Pola / Password / PIN perangkat</strong></li>
                <li>Sistem DP & pembayaran</li>
                <li>Kode servis auto-generate</li>
                <li><strong style="color:var(--primary)">Assign teknisi</strong></li>
                <li><strong style="color:var(--accent)">Pilih sparepart</strong> (Admin)</li>
                <li><strong style="color:var(--info)">Upload foto kondisi HP</strong></li>
                <li><strong style="color:#25D366">Auto Kirim Nota via WhatsApp</strong></li>
            </ul>
        </div>
    </div>
</div>

<script>
// Pilih pelanggan dari dropdown
function pilihPelanggan(select) {
    const opt = select.options[select.selectedIndex];
    const infoEl = document.getElementById('infoPelanggan');

    if (opt.value) {
        document.getElementById('noHp').value = opt.dataset.noHp || '';
        document.getElementById('namaP').value = opt.dataset.nama || '';
        document.getElementById('alamatP').value = opt.dataset.alamat || '';

        if (opt.dataset.userEmail) {
            infoEl.style.display = 'block';
            infoEl.innerHTML = '<i class="fas fa-check-circle"></i> Pelanggan ini sudah punya akun user: <strong>' + opt.dataset.userEmail + '</strong>';
        } else {
            infoEl.style.display = 'block';
            infoEl.innerHTML = '<i class="fas fa-info-circle" style="color:#f59e0b"></i> Pelanggan ini belum punya akun user. Saat simpan, akun user akan otomatis dibuat (password = No HP).';
            infoEl.style.background = '#fefce8';
            infoEl.style.borderColor = '#fde68a';
            infoEl.style.color = '#854d0e';
        }
    } else {
        infoEl.style.display = 'none';
    }
}

// Auto-fill dari No HP
document.getElementById('noHp').addEventListener('blur', function() {
    const hp = this.value.trim();
    if (hp.length >= 10) {
        fetch(`/api/pelanggan/search?q=${encodeURIComponent(hp)}`)
            .then(r => r.json())
            .then(data => {
                if (data && data.nama) {
                    document.getElementById('namaP').value = data.nama || '';
                    document.getElementById('alamatP').value = data.alamat || '';
                }
            });
    }
});

// ===== Master Data Tipe HP =====
let merkLoaded = false;
function loadMerks() {
    if (merkLoaded) return;
    fetch('/api/tipe-hp/search?q=')
        .then(r => r.json())
        .then(data => {
            const select = document.getElementById('merkHpSelect');
            const merks = [...new Set(data.map(d => d.merk))].sort();
            merks.forEach(merk => {
                const opt = document.createElement('option');
                opt.value = merk;
                opt.textContent = merk;
                select.appendChild(opt);
            });
            window._tipeHpData = data;
            merkLoaded = true;
        })
        .catch(() => {});
}
loadMerks();

function loadTipeHp() {
    const merk = document.getElementById('merkHpSelect').value;
    const tipeSelect = document.getElementById('tipeHpSelect');
    tipeSelect.innerHTML = '<option value="">-- Pilih Tipe --</option>';

    if (!merk || !window._tipeHpData) {
        tipeSelect.innerHTML = '<option value="">-- Pilih Merk dulu --</option>';
        return;
    }

    const types = window._tipeHpData
        .filter(d => d.merk === merk)
        .sort((a, b) => a.tipe.localeCompare(b.tipe));

    types.forEach(t => {
        const opt = document.createElement('option');
        opt.value = t.tipe;
        opt.textContent = t.tipe;
        opt.dataset.merk = t.merk;
        tipeSelect.appendChild(opt);
    });

    const tipeOs = document.querySelector('select[name="tipe"]');
    const appleMerks = ['Apple', 'iPhone', 'iPad'];
    if (appleMerks.includes(merk)) {
        tipeOs.value = 'Apple';
    } else {
        tipeOs.value = 'Android';
    }
}

function autoFillPerangkat() {
    const merk = document.getElementById('merkHpSelect').value;
    const tipe = document.getElementById('tipeHpSelect').value;
    const input = document.getElementById('perangkatInput');
    if (merk && tipe) {
        input.value = merk + ' ' + tipe;
    }
}

// ===== Kalkulasi Total Otomatis =====
function parseRupiah(val) {
    if (!val) return 0;
    return parseInt(String(val).replace(/[^0-9]/g, '')) || 0;
}

function formatRupiahDisplay(num) {
    return 'Rp ' + num.toLocaleString('id-ID');
}

function calculateTotal() {
    const biaya = parseRupiah(document.getElementById('biayaInput')?.value);
    const dp = parseRupiah(document.getElementById('dpInput')?.value);
    const sisa = Math.max(0, biaya - dp);
    document.getElementById('totalBayarDisplay').textContent = formatRupiahDisplay(sisa);
}

document.getElementById('biayaInput')?.addEventListener('input', calculateTotal);
document.getElementById('dpInput')?.addEventListener('input', calculateTotal);

// Sparepart management
function updateSparepartPrice(select) {
    const option = select.options[select.selectedIndex];
    const row = select.closest('.sparepart-row');
    const priceInput = row.querySelector('.sparepart-price');
    priceInput.value = option.dataset.harga || 0;
    if (window.applyRupiahFormatOnInput) applyRupiahFormatOnInput(priceInput);
    calculateTotal();
}

function addSparepartRow() {
    const container = document.getElementById('sparepartContainer');
    const firstRow = container.querySelector('.sparepart-row');
    const newRow = firstRow.cloneNode(true);
    const clonedSelect = newRow.querySelector('.sparepart-select');
    if (clonedSelect && window.teardownSparepart) {
        teardownSparepart(clonedSelect);
        clonedSelect.value = '';
        if (window.enhanceSparepart) enhanceSparepart(clonedSelect);
    }
    const qty = newRow.querySelector('.sparepart-qty');
    if (qty) qty.value = '1';
    const priceInput = newRow.querySelector('.sparepart-price');
    if (priceInput) {
        priceInput.value = '0';
        if (window.applyRupiahFormatOnInput) applyRupiahFormatOnInput(priceInput);
    }
    container.appendChild(newRow);
}

function removeSparepartRow(btn) {
    const container = document.getElementById('sparepartContainer');
    if (container.querySelectorAll('.sparepart-row').length > 1) {
        btn.closest('.sparepart-row').remove();
        calculateTotal();
    }
}

// Foto preview
document.querySelector('input[name="foto[]"]').addEventListener('change', function(e) {
    const preview = document.getElementById('fotoPreview');
    preview.innerHTML = '';
    Array.from(e.target.files).forEach(file => {
        const reader = new FileReader();
        reader.onload = function(ev) {
            preview.innerHTML += '<div style="width:80px;height:80px;border-radius:8px;overflow:hidden;border:1px solid #e2e8f0"><img src="' + ev.target.result + '" style="width:100%;height:100%;object-fit:cover"></div>';
        };
        reader.readAsDataURL(file);
    });
});

// ===== SERVICE PRICE AUTO-COMPLETE =====
let priceSearchTimer = null;
function searchServicePrice(query) {
    clearTimeout(priceSearchTimer);
    const suggestions = document.getElementById('priceSuggestions');
    if (!query || query.length < 2) {
        suggestions.style.display = 'none';
        return;
    }
    priceSearchTimer = setTimeout(() => {
        const merk = document.getElementById('merkHpSelect')?.value || '';
        fetch('/api/service-prices/search?q=' + encodeURIComponent(query) + '&merk=' + encodeURIComponent(merk))
            .then(r => r.json())
            .then(data => {
                if (!data || data.length === 0) {
                    suggestions.style.display = 'none';
                    return;
                }
                suggestions.innerHTML = '';
                data.forEach(sp => {
                    const div = document.createElement('div');
                    div.style.cssText = 'padding:10px 14px;border-bottom:1px solid #f1f5f9;cursor:pointer;transition:background .15s;display:flex;justify-content:space-between;align-items:center';
                    div.onmouseover = function() { this.style.background = '#f0fdf4'; };
                    div.onmouseout = function() { this.style.background = 'transparent'; };
                    const leftHtml = '<div>' +
                        '<div style="font-weight:600;font-size:.84rem;color:#1e293b">' + sp.kerusakan + '</div>' +
                        '<div style="font-size:.68rem;color:#64748b">' +
                            (sp.merk_hp ? sp.merk_hp : 'Semua Merk') +
                            (sp.tipe_hp ? ' — ' + sp.tipe_hp : '') +
                            (sp.kategori ? ' — ' + sp.kategori : '') +
                        '</div>' +
                    '</div>';
                    const rightHtml = '<div style="text-align:right">' +
                        '<div style="font-weight:700;color:var(--success);font-size:.9rem">' + formatRupiahDisplay(sp.harga_jasa) + '</div>' +
                    '</div>';
                    div.innerHTML = leftHtml + rightHtml;
                    div.addEventListener('click', function() {
                        document.getElementById('keluhanInput').value = sp.kerusakan;
                        document.getElementById('biayaInput').value = sp.harga_jasa;
                        if (window.applyRupiahFormatOnInput) window.applyRupiahFormatOnInput(document.getElementById('biayaInput'));
                        suggestions.style.display = 'none';
                        calculateTotal();
                    });
                    suggestions.appendChild(div);
                });
                suggestions.style.display = 'block';
            })
            .catch(() => { suggestions.style.display = 'none'; });
    }, 300);
}

// ===== PATTERN LOCK (Pola Kunci) =====
let currentPattern = [];

function togglePatternDot(btn) {
    const num = btn.dataset.num;
    const index = currentPattern.indexOf(num);

    if (index === -1) {
        currentPattern.push(num);
        btn.style.background = 'var(--primary)';
        btn.style.borderColor = 'var(--primary)';
        btn.style.color = '#fff';
        btn.style.transform = 'scale(1.1)';
        setTimeout(() => { btn.style.transform = 'scale(1)'; }, 150);
    } else {
        currentPattern.splice(index, 1);
        btn.style.background = '#fff';
        btn.style.borderColor = '#cbd5e1';
        btn.style.color = '#64748b';
    }

    updatePatternDisplay();
}

function updatePatternDisplay() {
    const display = document.getElementById('patternDisplay');
    const input = document.getElementById('polaInput');

    if (currentPattern.length === 0) {
        display.innerHTML = '— belum ada pola —';
        display.style.color = '#94a3b8';
        input.value = '';
    } else {
        const dots = '● '.repeat(currentPattern.length).trim();
        display.innerHTML = `<span style="color:#94a3b8">${dots}</span> <span style="color:#64748b;font-size:.7rem">(${currentPattern.join('-')})</span>`;
        display.style.color = 'var(--primary)';
        input.value = currentPattern.join('-');
    }
}

function clearPattern() {
    currentPattern = [];
    document.querySelectorAll('.pattern-dot').forEach(dot => {
        dot.style.background = '#fff';
        dot.style.borderColor = '#cbd5e1';
        dot.style.color = '#64748b';
    });
    updatePatternDisplay();
}

// ===== TOGGLE PASSWORD/PIN VISIBILITY =====
function togglePasswordVisibility(inputId, btn) {
    const input = document.getElementById(inputId);
    const icon = btn.querySelector('i');
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}

// ===== KIRIM DATA KEAMANAN KE WA TEKNISI =====
function kirimKeTeknisi() {
    const pola = document.getElementById('polaInput').value;
    const password = document.getElementById('passwordInput').value;
    const pin = document.getElementById('pinInput').value;
    const kodeServis = document.getElementById('kodeServis').value;
    const perangkat = document.getElementById('perangkatInput').value;
    const nama = document.getElementById('namaP').value;

    if (!pola && !password && !pin) {
        alert('Belum ada data keamanan (pola/password/PIN) untuk dikirim.');
        return;
    }

    const teknisiSelect = document.getElementById('teknisiSelect');
    const teknisiOpt = teknisiSelect?.selectedOptions[0];
    let noHpTeknisi = teknisiOpt?.dataset?.noHp || '';
    const namaTeknisi = teknisiOpt?.text || 'Teknisi';

    if (!noHpTeknisi) {
        noHpTeknisi = prompt(`Masukkan No. HP ${namaTeknisi} (belum tersimpan):`);
        if (!noHpTeknisi) return;
    }

    noHpTeknisi = noHpTeknisi.replace(/^0/, '62').replace(/[^0-9]/g, '');

    let pesan = `*🔒 DATA KEAMANAN PERANGKAT*\n`;
    pesan += `========================\n`;
    pesan += `Kode Servis: *${kodeServis}*\n`;
    pesan += `Pelanggan: ${nama}\n`;
    pesan += `Perangkat: ${perangkat}\n`;
    pesan += `------------------------\n`;
    if (pola) pesan += `Pola (urutan): *${pola}*\n`;
    if (password) pesan += `Password: *${password}*\n`;
    if (pin) pesan += `PIN: *${pin}*\n`;
    pesan += `========================\n`;
    pesan += `⚠️ _Data ini hanya untuk teknisi, jangan dibagikan ke pihak lain._`;

    const waUrl = `https://api.whatsapp.com/send?phone=${noHpTeknisi}&text=${encodeURIComponent(pesan)}`;
    window.open(waUrl, '_blank');
}

// ===== ANTI AUTO-FILL TAMBAHAN =====
// Force clear IMEI, Password, PIN saat halaman dimuat (untuk mencegah auto-fill browser)
window.addEventListener('DOMContentLoaded', function() {
    setTimeout(() => {
        const imeiInput = document.getElementById('imeiInput');
        if (imeiInput && isNaN(imeiInput.value.replace(/[^0-9]/g, ''))) {
            imeiInput.value = '';
        }
        
        const passwordInput = document.getElementById('passwordInput');
        if (passwordInput && passwordInput.value && passwordInput.value.includes('@')) {
            passwordInput.value = '';
        }
        
        const pinInput = document.getElementById('pinInput');
        if (pinInput && pinInput.value && isNaN(pinInput.value.replace(/[^0-9]/g, ''))) {
            pinInput.value = '';
        }
    }, 100);
});

// ===== CRITICAL: Strip empty sparepart inputs before submit + AUTO WA =====
document.querySelectorAll('form[method="POST"]').forEach(form => {
    form.addEventListener('submit', function(e) {
        // ===== AUTO KIRIM WA (NOTA PELANGGAN) =====
        const autoWA = document.getElementById('autoWaCheckbox')?.checked;
        if (autoWA) {
            const noHp = document.getElementById('noHp').value.replace(/^0/, '62').replace(/[^0-9]/g, '');
            const nama = document.getElementById('namaP').value;
            const kodeServis = document.getElementById('kodeServis')?.value || 'Menunggu Generate';
            const perangkat = document.getElementById('perangkatInput').value;
            const keluhan = document.getElementById('keluhanInput').value;
            const biaya = document.getElementById('biayaInput').value;
            const dp = document.getElementById('dpInput').value;
            const sisa = document.getElementById('totalBayarDisplay').textContent;
            const eta = document.querySelector('input[name="eta"]').value;
            
            let pesan = `*NOTA SERVIS DIGITAL*\n`;
            pesan += `========================\n`;
            pesan += `Kode Servis: *${kodeServis}*\n`;
            pesan += `Pelanggan: ${nama}\n`;
            pesan += `No. HP: ${document.getElementById('noHp').value}\n`;
            pesan += `Perangkat: ${perangkat}\n`;
            pesan += `------------------------\n`;
            pesan += `*Keluhan:*\n${keluhan}\n\n`;
            pesan += `*Rincian Biaya:*\n`;
            pesan += `Total Biaya: ${biaya}\n`;
            pesan += `DP Dibayar: ${dp}\n`;
            pesan += `Sisa Pembayaran: *${sisa}*\n`;
            if(eta) pesan += `Estimasi Selesai: ${eta}\n`;
            pesan += `========================\n`;
            pesan += `Terima kasih telah mempercayakan servis Anda kepada kami. Anda dapat memantau status servis menggunakan kode di atas.`;
            // CATATAN: Data keamanan (pola/password/pin) TIDAK dimasukkan ke pesan pelanggan untuk keamanan
                        
            const waUrl = `https://api.whatsapp.com/send?phone=${noHp}&text=${encodeURIComponent(pesan)}`;
            window.open(waUrl, '_blank');
        }

        // Remove name from sparepart selects/inputs yang kosong
        this.querySelectorAll('.sparepart-select').forEach(sel => {
            if (!sel.value) {
                if (!sel.dataset.origName && sel.hasAttribute('name')) sel.dataset.origName = sel.getAttribute('name');
                sel.removeAttribute('name');
            }
        });
        this.querySelectorAll('.sparepart-price').forEach(inp => {
            const row = inp.closest('.sparepart-row');
            if (row) {
                const sel = row.querySelector('.sparepart-select');
                if (!sel || !sel.value) {
                    if (!inp.dataset.origName && inp.hasAttribute('name')) inp.dataset.origName = inp.getAttribute('name');
                    inp.removeAttribute('name');
                }
            }
        });
        this.querySelectorAll('.sparepart-qty').forEach(inp => {
            const row = inp.closest('.sparepart-row');
            if (row) {
                const sel = row.querySelector('.sparepart-select');
                if (!sel || !sel.value) {
                    if (!inp.dataset.origName && inp.hasAttribute('name')) inp.dataset.origName = inp.getAttribute('name');
                    inp.removeAttribute('name');
                }
            }
        });
    });
});
</script>
@endsection