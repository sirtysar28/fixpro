@extends('layouts.app')
@section('title', 'Pembelian Baru')

@section('content')
<h2 class="mb-4"><i class="fas fa-truck-loading" style="color:var(--primary);margin-right:6px"></i>Pembelian Baru</h2>

<div class="card mb-4" style="background:linear-gradient(135deg,#ecfdf5,#d1fae5);border:1px solid #6ee7b7;padding:12px 16px;font-size:.78rem;color:#065f46">
    <i class="fas fa-info-circle"></i> Setiap pembelian akan <strong>menambah stok otomatis</strong> & memperbarui <strong>harga modal (HPP)</strong> sesuai harga beli terbaru. Jika bayar kurang dari total, sisanya tercatat sebagai <strong>hutang supplier</strong>.
</div>

<form method="POST" action="{{ route('pembelian.store') }}" id="formPembelian">
    @csrf
    <div class="card mb-4">
        <h3 style="font-size:.95rem;margin-bottom:16px"><i class="fas fa-building"></i> Data Supplier</h3>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:14px">
            <div class="form-group">
                <label>Nama Supplier *</label>
                <input type="text" name="supplier_nama" class="form-input" required placeholder="PT Sumber Sparepart">
            </div>
            <div class="form-group">
                <label>Kontak (No HP)</label>
                <input type="text" name="supplier_kontak" class="form-input" placeholder="0812...">
            </div>
            <div class="form-group" style="grid-column:1/-1">
                <label>Alamat</label>
                <input type="text" name="supplier_alamat" class="form-input" placeholder="Alamat supplier">
            </div>
            <div class="form-group">
                <label>Tanggal Pembelian *</label>
                <input type="date" name="tanggal" class="form-input" required value="{{ old('tanggal', date('Y-m-d')) }}">
            </div>
            <div class="form-group">
                <label>Jatuh Tempo (opsional)</label>
                <input type="date" name="tanggal_jatuh_tempo" class="form-input" value="{{ old('tanggal_jatuh_tempo') }}">
            </div>
            <div class="form-group">
                <label>Metode Bayar</label>
                <select name="metode_bayar" class="form-input">
                    @foreach(['Cash','Transfer','QRIS'] as $m)
                    <option value="{{ $m }}" {{ old('metode_bayar') === $m ? 'selected' : '' }}>{{ $m }}</option>
                    @endforeach
                </select>
            </div>
        </div>
    </div>

    <div class="card mb-4">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
            <h3 style="font-size:.95rem"><i class="fas fa-boxes"></i> Daftar Barang</h3>
            <button type="button" onclick="addRow()" class="btn btn-success btn-sm" style="background:#16a34a;color:#fff"><i class="fas fa-plus"></i> Tambah Baris</button>
        </div>
        <div class="table-wrap">
            <table id="itemTable">
                <thead><tr><th>#</th><th>Pilih Barang (atau ketik nama baru)</th><th>Qty</th><th>Harga Beli (Modal)</th><th>Harga Jual</th><th>Subtotal</th><th></th></tr></thead>
                <tbody id="itemBody"></tbody>
            </table>
        </div>
    </div>

    <div class="card mb-4">
        <h3 style="font-size:.95rem;margin-bottom:16px"><i class="fas fa-calculator"></i> Ringkasan & Pembayaran</h3>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:24px">
            <div>
                <div class="form-group">
                    <label>Diskon (%)</label>
                    <input type="number" name="diskon_persen" id="diskonPersen" class="form-input" min="0" max="100" step="0.01" value="{{ old('diskon_persen', 0) }}" oninput="recalc()">
                </div>
                <div class="form-group">
                    <label>Diskon Nominal (Rp)</label>
                    <input type="number" name="diskon_nominal" id="diskonNominal" class="form-input" min="0" step="1000" value="{{ old('diskon_nominal', 0) }}" oninput="recalc()">
                </div>
                <div class="form-group">
                    <label>Catatan</label>
                    <textarea name="catatan" class="form-input" rows="2">{{ old('catatan') }}</textarea>
                </div>
            </div>
            <div style="background:#f8fafc;border-radius:12px;padding:16px">
                <div style="display:flex;justify-content:space-between;margin-bottom:8px"><span>Subtotal</span><strong id="sumSubtotal">Rp 0</strong></div>
                <div style="display:flex;justify-content:space-between;margin-bottom:8px;color:#dc2626"><span>Diskon</span><strong id="sumDiskon">- Rp 0</strong></div>
                <div style="display:flex;justify-content:space-between;padding-top:10px;border-top:2px solid #e2e8f0;margin-bottom:14px;font-size:1.1rem"><strong>Total</strong><strong id="sumTotal" style="color:var(--primary)">Rp 0</strong></div>
                <div class="form-group">
                    <label>Dibayar (Rp)</label>
                    <input type="number" name="dibayar" id="dibayar" class="form-input" min="0" step="1000" value="{{ old('dibayar', 0) }}" oninput="recalc()">
                </div>
                <div style="display:flex;justify-content:space-between;margin-top:8px;color:#dc2626"><span>Sisa Hutang</span><strong id="sumSisa">Rp 0</strong></div>
            </div>
        </div>
        <div style="margin-top:16px;display:flex;gap:8px">
            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Simpan Pembelian</button>
            <a href="{{ route('pembelian.index') }}" class="btn btn-secondary">Batal</a>
        </div>
    </div>
</form>

<script>
@php
    $stokListData = $stoks->map(function($s) {
        return ['id'=>$s->id,'kode'=>$s->kode,'nama'=>$s->nama,'modal'=>$s->modal,'jual'=>$s->jual];
    });
@endphp
const stokList = @json($stokListData);
let rowCount = 0;

function addRow(data = {}) {
    rowCount++;
    const body = document.getElementById('itemBody');
    const tr = document.createElement('tr');
    tr.id = 'row_' + rowCount;

    let opts = '<option value="">-- Pilih barang existing (atau ketik di bawah) --</option>';
    stokList.forEach(s => {
        opts += `<option value="${s.id}" data-modal="${s.modal}" data-jual="${s.jual}" data-kode="${s.kode}" data-nama="${s.nama.replace(/"/g,'&quot;')}">${s.nama} (${s.kode}) — modal ${formatRpJs(s.modal)}</option>`;
    });

    tr.innerHTML =
        '<td>' + rowCount + '</td>' +
        '<td style="min-width:280px">' +
            '<select class="form-input stok-pick" onchange="onPick(this)" style="font-size:.78rem;margin-bottom:4px">' + opts + '</select>' +
            '<input type="text" class="form-input nama-input" name="items[' + (rowCount-1) + '][nama]" placeholder="Nama barang (ketik jika baru)" required style="font-size:.78rem;padding:5px 8px">' +
            '<input type="hidden" class="stok-id" name="items[' + (rowCount-1) + '][stok_id]">' +
            '<input type="hidden" class="kode-input" name="items[' + (rowCount-1) + '][kode]">' +
        '</td>' +
        '<td><input type="number" class="form-input qty-input" name="items[' + (rowCount-1) + '][qty]" min="1" value="1" required style="width:80px;font-size:.78rem;padding:5px 8px" oninput="recalc()"></td>' +
        '<td><input type="number" class="form-input beli-input" name="items[' + (rowCount-1) + '][harga_beli]" min="0" step="100" required value="0" style="width:120px;font-size:.78rem;padding:5px 8px" oninput="recalc()"></td>' +
        '<td><input type="number" class="form-input jual-input" name="items[' + (rowCount-1) + '][harga_jual]" min="0" step="100" value="0" style="width:120px;font-size:.78rem;padding:5px 8px"></td>' +
        '<td style="font-weight:600" class="sub-cell">Rp 0</td>' +
        '<td><button type="button" onclick="removeRow(\'row_' + rowCount + '\')" style="background:#fee2e2;border:none;color:#dc2626;width:30px;height:30px;border-radius:6px;cursor:pointer"><i class="fas fa-times"></i></button></td>';
    body.appendChild(tr);
}

function onPick(sel) {
    const tr = sel.closest('tr');
    const opt = sel.selectedOptions[0];
    if (opt && opt.value) {
        tr.querySelector('.stok-id').value = opt.value;
        tr.querySelector('.kode-input').value = opt.dataset.kode;
        tr.querySelector('.nama-input').value = opt.dataset.nama;
        tr.querySelector('.beli-input').value = opt.dataset.modal;
        tr.querySelector('.jual-input').value = opt.dataset.jual;
    } else {
        tr.querySelector('.stok-id').value = '';
        tr.querySelector('.kode-input').value = '';
    }
    recalc();
}

function removeRow(id) {
    document.getElementById(id)?.remove();
    recalc();
}

function recalc() {
    let subtotal = 0;
    document.querySelectorAll('#itemBody tr').forEach(tr => {
        const qty = parseFloat(tr.querySelector('.qty-input')?.value || 0);
        const beli = parseFloat(tr.querySelector('.beli-input')?.value || 0);
        const sub = qty * beli;
        subtotal += sub;
        const cell = tr.querySelector('.sub-cell');
        if (cell) cell.textContent = 'Rp ' + formatRpJs(sub);
    });

    const dpersen = parseFloat(document.getElementById('diskonPersen')?.value || 0);
    const dnom = parseFloat(document.getElementById('diskonNominal')?.value || 0);
    const diskon = (subtotal * dpersen / 100) + dnom;
    const total = Math.max(0, subtotal - diskon);
    const dibayar = parseFloat(document.getElementById('dibayar')?.value || 0);
    const sisa = Math.max(0, total - dibayar);

    document.getElementById('sumSubtotal').textContent = 'Rp ' + formatRpJs(subtotal);
    document.getElementById('sumDiskon').textContent = '- Rp ' + formatRpJs(diskon);
    document.getElementById('sumTotal').textContent = 'Rp ' + formatRpJs(total);
    document.getElementById('sumSisa').textContent = 'Rp ' + formatRpJs(sisa);
}

function formatRpJs(n) {
    n = Math.round(n || 0);
    return n.toLocaleString('id-ID');
}

// init 3 baris kosong
addRow(); addRow(); addRow();
recalc();
</script>
@endsection
