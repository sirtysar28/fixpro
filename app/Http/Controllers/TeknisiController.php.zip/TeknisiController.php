<?php

namespace App\Http\Controllers;

use App\Models\Teknisi;
use App\Services\AuditLogService;
use Illuminate\Http\Request;

class TeknisiController extends Controller
{
    public function index()
    {
        $user = auth()->user();
        $cabangId = $user->getActiveCabangId();

        $query = Teknisi::withCount(['servis', 'servis as selesai_count' => fn ($q) => $q->where('status', 'Selesai')])
            ->with(['servis' => fn ($q) => $q->where('status', 'Selesai')]);

        // Super Admin + "Semua Cabang" = tampilkan semua
        // Admin cabang / Super Admin pilih cabang spesifik = filter cabang itu saja
        if ($cabangId) {
            $query->where('cabang_id', $cabangId);
        }

        $teknisis = $query->orderBy('nama')
            ->get()
            ->map(function ($t) {
                $t->omset = $t->servis->sum('biaya');
                $aktifCount = $t->servis()->whereIn('status', ['Masuk', 'Proses'])->count();
                $t->aktif_count = $aktifCount;
                return $t;
            });
        return view('teknisi.index', compact('teknisis'));
    }

    public function create()
    {
        $cabangs = \App\Models\Cabang::where('aktif', true)->orderBy('nama')->get();
        return view('teknisi.create', compact('cabangs'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'nama' => 'required',
            'no_wa' => 'nullable',
            'spesialisasi' => 'required',
            'alamat' => 'nullable',
            'cabang_id' => 'nullable|exists:cabang,id',
            'bagi_hasil' => 'nullable|numeric|min:0|max:100',
        ]);
        $t = Teknisi::create($validated);
        AuditLogService::created('teknisi', "Menambahkan teknisi: {$validated['nama']} (Bagi Hasil: " . ($validated['bagi_hasil'] ?? 35) . "%)", $t);
        return redirect()->route('teknisi.index')->with('success', 'Teknisi berhasil ditambahkan!');
    }

    public function edit(Teknisi $teknisi)
    {
        $cabangs = \App\Models\Cabang::where('aktif', true)->orderBy('nama')->get();
        return view('teknisi.edit', compact('teknisi', 'cabangs'));
    }

    public function update(Request $request, Teknisi $teknisi)
    {
        $validated = $request->validate([
            'nama' => 'required',
            'no_wa' => 'nullable',
            'spesialisasi' => 'required',
            'alamat' => 'nullable',
            'aktif' => 'boolean',
            'cabang_id' => 'nullable|exists:cabang,id',
            'bagi_hasil' => 'nullable|numeric|min:0|max:100',
            'link_user_id' => 'nullable|exists:users,id',
        ]);

        $linkUserId = $validated['link_user_id'] ?? null;
        unset($validated['link_user_id']);

        $teknisi->update($validated);

        // Link/unlink user account
        // First remove old links
        \App\Models\User::where('teknisi_id', $teknisi->id)->update(['teknisi_id' => null]);

        if ($linkUserId) {
            \App\Models\User::where('id', $linkUserId)->update(['teknisi_id' => $teknisi->id]);
        }

        AuditLogService::updated('teknisi', "Mengupdate teknisi: {$teknisi->nama}" . ($linkUserId ? ' (linked user)' : ''), $teknisi);
        return redirect()->route('teknisi.index')->with('success', 'Teknisi berhasil diupdate!');
    }

    public function destroy(Teknisi $teknisi)
    {
        AuditLogService::deleted('teknisi', "Menghapus teknisi: {$teknisi->nama}", $teknisi);
        $teknisi->delete();
        return redirect()->route('teknisi.index')->with('success', 'Teknisi berhasil dihapus!');
    }
}
