<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Nota Servis {{ $servis->kode }}</title>
<style>
    @page { margin: 14mm 12mm; size: A4; }
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'DejaVu Sans', sans-serif; color: #1e293b; font-size: 11px; }
    .header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 3px solid #0d9488; padding-bottom: 12px; margin-bottom: 16px; }
    .brand-name { font-size: 20px; font-weight: bold; color: #0d9488; }
    .brand-sub { font-size: 10px; color: #64748b; margin-top: 2px; }
    .brand-addr { font-size: 9px; color: #94a3b8; margin-top: 4px; line-height: 1.5; }
    .nota-box { text-align: right; }
    .nota-title { font-size: 18px; font-weight: bold; color: #0f172a; letter-spacing: 1px; }
    .nota-kode { font-size: 12px; color: #0d9488; font-weight: bold; margin-top: 2px; }
    .nota-tgl { font-size: 9px; color: #94a3b8; margin-top: 4px; }

    .info-grid { display: flex; gap: 16px; margin-bottom: 16px; }
    .info-card { flex: 1; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 10px 12px; }
    .info-card h4 { font-size: 9px; text-transform: uppercase; letter-spacing: .5px; color: #94a3b8; margin-bottom: 6px; font-weight: 700; }
    .info-row { display: flex; padding: 2px 0; font-size: 10px; }
    .info-row .lbl { width: 70px; color: #64748b; }
    .info-row .val { font-weight: 600; flex: 1; }

    table.items { width: 100%; border-collapse: collapse; margin-bottom: 14px; }
    table.items th { background: #0d9488; color: #fff; font-size: 9px; text-transform: uppercase; letter-spacing: .3px; padding: 7px 8px; text-align: left; }
    table.items th.right { text-align: right; }
    table.items td { padding: 6px 8px; border-bottom: 1px solid #e2e8f0; font-size: 10px; }
    table.items td.right { text-align: right; }
    table.items tr.total td { background: #f0fdf4; font-weight: bold; border-top: 2px solid #0d9488; }

    .biaya-box { margin-left: auto; width: 55%; margin-bottom: 16px; }
    .biaya-row { display: flex; justify-content: space-between; padding: 5px 10px; font-size: 11px; border-bottom: 1px dashed #e2e8f0; }
    .biaya-row.grand { background: linear-gradient(135deg,#0d9488,#065f46); color: #fff; font-size: 14px; font-weight: bold; padding: 10px; border-radius: 6px; border: none; margin-top: 6px; }
    .biaya-row.grand .v { font-size: 15px; }



    .footer { margin-top: 20px; border-top: 2px solid #e2e8f0; padding-top: 12px; text-align: center; }
    .footer thx { font-size: 11px; font-weight: bold; color: #0d9488; }
    .footer .sub { font-size: 9px; color: #94a3b8; margin-top: 4px; }
    .sign { display: flex; justify-content: space-between; margin-top: 24px; }
    .sign-box { text-align: center; width: 40%; }
    .sign-box .line { margin-top: 40px; border-top: 1px solid #475569; padding-top: 4px; font-size: 10px; font-weight: 600; }
</style>
</head>
<body>

{{-- HEADER --}}
<div class="header">
    <div>
        <div class="brand-name">{{ $settings['nama_toko'] }}</div>
        @if($settings['alamat'])<div class="brand-sub">{{ $settings['alamat'] }}</div>@endif
        @if($settings['telp'])<div class="brand-addr">Telp/WA: {{ $settings['telp'] }}</div>@endif
    </div>
    <div class="nota-box">
        <div class="nota-title">NOTA SERVIS</div>
        <div class="nota-kode">{{ $servis->kode }}</div>
        <div class="nota-tgl">{{ $servis->tanggal?->format('d/m/Y') }} @if($servis->cabang) · {{ $servis->cabang->nama }}@endif</div>
    </div>
</div>

{{-- INFO PELANGGAN & PERANGKAT --}}
<div class="info-grid">
    <div class="info-card">
        <h4>Pelanggan</h4>
        <div class="info-row"><span class="lbl">Nama</span><span class="val">{{ $servis->pelanggan?->nama ?? '-' }}</span></div>
        <div class="info-row"><span class="lbl">No. HP</span><span class="val">{{ $servis->pelanggan?->no_hp ?? '-' }}</span></div>
        @if($servis->pelanggan?->alamat)<div class="info-row"><span class="lbl">Alamat</span><span class="val">{{ $servis->pelanggan->alamat }}</span></div>@endif
    </div>
    <div class="info-card">
        <h4>Perangkat</h4>
        <div class="info-row"><span class="lbl">Unit</span><span class="val">{{ $servis->perangkat }}</span></div>
        <div class="info-row"><span class="lbl">Tipe</span><span class="val">{{ $servis->tipe }}</span></div>
        @if($servis->imei)<div class="info-row"><span class="lbl">IMEI</span><span class="val">{{ $servis->imei }}</span></div>@endif
        <div class="info-row"><span class="lbl">Keluhan</span><span class="val">{{ $servis->keluhan }}</span></div>
    </div>
</div>

{{-- Hitung total sparepart --}}
@php
    $totalSp = 0;
    if ($servis->spareparts && count($servis->spareparts) > 0) {
        foreach ($servis->spareparts as $sp) {
            $totalSp += (float) ($sp['harga'] ?? 0) * (int) ($sp['qty'] ?? 1);
        }
    }
    // biaya = harga KESELURUHAN (sudah termasuk sparepart). Sparepart TIDAK ditambah lagi.
    $grandTotal = (float) $servis->biaya;
    $sisaBayar = max(0, $grandTotal - (float) $servis->dp);
@endphp

{{-- SPAREPART --}}
@if($servis->spareparts && count($servis->spareparts) > 0)
<table class="items">
    <thead>
        <tr><th>Sparepart Digunakan</th><th class="right" style="width:60px">Qty</th><th class="right" style="width:120px">Harga</th></tr>
    </thead>
    <tbody>
        @foreach($servis->spareparts as $sp)
        <tr><td>{{ $sp['nama'] ?? '-' }} @if(!empty($sp['kode']))<span style="color:#94a3b8">({{ $sp['kode'] }})</span>@endif</td><td class="right">{{ $sp['qty'] ?? 1 }}</td><td class="right">Rp {{ number_format(($sp['harga'] ?? 0) * ($sp['qty'] ?? 1), 0, ',', '.') }}</td></tr>
        @endforeach
        <tr class="total"><td colspan="2">Subtotal Sparepart</td><td class="right">Rp {{ number_format($totalSp, 0, ',', '.') }}</td></tr>
    </tbody>
</table>
@endif

{{-- RINCIAN BIAYA --}}
<div class="biaya-box">
    <div class="biaya-row"><span>Total Biaya Servis</span><span>Rp {{ number_format($servis->biaya, 0, ',', '.') }}</span></div>
    @if($totalSp > 0)
    <div class="biaya-row" style="color:#7c3aed;font-size:10px"><span>&nbsp; ↳ termasuk sparepart</span><span>Rp {{ number_format($totalSp, 0, ',', '.') }}</span></div>
    @endif
    <div class="biaya-row" style="font-weight:700;border-top:1px solid #0d9488;border-bottom:none"><span>Total Tagihan</span><span>Rp {{ number_format($grandTotal, 0, ',', '.') }}</span></div>
    @if($servis->dp > 0)
    <div class="biaya-row"><span>Uang Muka (DP)</span><span style="color:#dc2626">- Rp {{ number_format($servis->dp, 0, ',', '.') }}</span></div>
    @endif
    <div class="biaya-row grand">
        <span>SISA YANG HARUS DIBAYAR</span>
        <span class="v">Rp {{ number_format($sisaBayar, 0, ',', '.') }}</span>
    </div>
</div>

{{-- INFO TAMBAHAN --}}
<div class="info-grid">
    <div class="info-card">
        <h4>Detail Servis</h4>
        <div class="info-row"><span class="lbl">Teknisi</span><span class="val">{{ $servis->teknisi?->nama ?? '-' }}</span></div>
        <div class="info-row"><span class="lbl">Status</span><span class="val">{{ $servis->status }}</span></div>
        @if($servis->garansi)<div class="info-row"><span class="lbl">Garansi</span><span class="val">{{ $servis->garansi }} hari @if($servis->tanggal_garansi)(s/d {{ $servis->tanggal_garansi?->format('d/m/Y') }})@endif</span></div>@endif
        @if($servis->catatan)<div class="info-row"><span class="lbl">Catatan</span><span class="val">{{ $servis->catatan }}</span></div>@endif
    </div>
</div>


{{-- TANDA TANGAN --}}
<div class="sign">
    <div class="sign-box">
        <div style="font-size:10px;color:#64748b">Pelanggan</div>
        <div class="line">{{ $servis->pelanggan?->nama ?? '-' }}</div>
    </div>
    <div class="sign-box">
        <div style="font-size:10px;color:#64748b">Hormat Kami</div>
        <div class="line">{{ $settings['nama_toko'] }}</div>
    </div>
</div>

{{-- FOOTER --}}
<div class="footer">
    <thx>Terima kasih telah mempercayakan servis HP Anda kepada kami! 🙏</thx>
    <div class="sub">Nota ini sah dan tidak perlu distempel. Simpan sebagai bukti garansi.<br>Beri tahu kami jika ada kendala. — {{ $settings['nama_toko'] }}</div>
</div>

</body>
</html>
