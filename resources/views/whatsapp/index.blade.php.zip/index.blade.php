@extends('layouts.app')
@section('title', 'WhatsApp Web — Inbox')

@section('content')
<h2 class="mb-4" style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
    <i class="fab fa-whatsapp" style="color:#25D366;font-size:1.5rem"></i> WhatsApp Inbox
    @if($enabled)
    <span id="deviceBadge" class="wa-badge {{ ($deviceStatus['connected'] ?? false) ? 'online' : 'offline' }}">
        <span class="dot"></span>
        @if(($deviceStatus['connected'] ?? false)) Terhubung @else Terputus @endif
    </span>
    @else
    <span class="wa-badge offline"><span class="dot"></span> Belum dikonfigurasi</span>
    @endif
    <span style="margin-left:auto;font-size:.8rem;color:#64748b" id="totalUnread">{{ $totalUnread }} pesan belum dibaca</span>
</h2>

@if(!$enabled)
<div class="card mb-4" style="background:#fef3c7;border:1px solid #fcd34d;color:#78350f;padding:14px 18px">
    <i class="fas fa-exclamation-triangle"></i>
    <strong>WhatsApp belum aktif.</strong> Hubungkan akun Fonnte di menu <a href="{{ route('settings.index') }}" style="color:#b45309;text-decoration:underline">Pengaturan</a> (isi API Key Fonnte) lalu scan QR di bawah untuk masuk.
</div>
@endif

<div class="card mb-4" id="qrCard" style="@if(($deviceStatus['connected'] ?? false)) display:none @endif">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
        <h3 style="font-size:.92rem;margin:0"><i class="fas fa-qrcode" style="color:var(--primary)"></i> Login WhatsApp Web (Scan QR)</h3>
        <div style="display:flex;gap:6px">
            <button onclick="checkDeviceStatus()" class="btn btn-secondary btn-sm"><i class="fas fa-plug"></i> Cek Status</button>
            <button onclick="loadQr()" class="btn btn-secondary btn-sm"><i class="fas fa-sync"></i> Refresh QR</button>
        </div>
    </div>
    <div id="qrContainer" style="text-align:center;padding:20px">
        <p style="color:#64748b;font-size:.82rem">Klik "Refresh QR" untuk menampilkan kode QR. Scan dengan WhatsApp di HP → <strong>Setelan → WhatsApp Web → Tautkan perangkat</strong>.</p>
    </div>
</div>

<div class="card mb-4">
    <form method="GET" style="display:flex;gap:8px;flex-wrap:wrap">
        <input type="text" name="search" class="form-input" value="{{ request('search') }}" placeholder="Cari nama / nomor / isi pesan..." style="flex:1;min-width:200px;padding:8px 12px;font-size:.84rem">
        <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-search"></i> Cari</button>
    </form>
</div>

<div class="card">
    <div class="card-header" style="display:flex;justify-content:space-between;align-items:center">
        <h3 style="font-size:.92rem;margin:0"><i class="fas fa-inbox"></i> Percakapan</h3>
        <span class="text-muted text-sm" id="serverTime"></span>
    </div>
    <div id="roomsList">
        <div class="table-wrap">
            <table>
                <thead><tr><th>Nama / Nomor</th><th>Pesan Terakhir</th><th>Waktu</th><th>Status</th></tr></thead>
                <tbody id="roomsTbody">
                    @foreach($rooms as $room)
                    <tr data-room-id="{{ $room->id }}" data-last="{{ $room->last_message_at?->timestamp }}" style="cursor:pointer" onclick="location.href='{{ route('whatsapp.show', $room) }}'">
                        <td>
                            <strong>{{ $room->name ?: $room->number }}</strong>
                            @if($room->name)<br><span style="font-size:.7rem;color:#94a3b8">{{ $room->number }}</span>@endif
                        </td>
                        <td style="max-width:300px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
                            @if($room->last_direction === 'out')<i class="fas fa-reply" style="color:#94a3b8;font-size:.7rem"></i> @endif
                            {{ $room->last_message ?: '(kosong)' }}
                        </td>
                        <td style="font-size:.74rem;color:#64748b">{{ $room->last_message_at?->diffForHumans() ?? '-' }}</td>
                        <td>
                            @if($room->unread > 0)
                            <span class="wa-badge unread-badge">{{ $room->unread }}</span>
                            @else
                            <span style="font-size:.7rem;color:#94a3b8">Dibaca</span>
                            @endif
                        </td>
                    </tr>
                    @endforeach
                    @if($rooms->count() === 0)
                    <tr><td colspan="4" style="text-align:center;color:#94a3b8;padding:24px">Belum ada percakapan masuk.</td></tr>
                    @endif
                </tbody>
            </table>
        </div>
    </div>
    {{ $rooms->links() }}
</div>

<style>
.wa-badge { display:inline-flex;align-items:center;gap:6px;padding:3px 10px;border-radius:14px;font-size:.72rem;font-weight:700 }
.wa-badge .dot { width:8px;height:8px;border-radius:50%;display:inline-block }
.wa-badge.online { background:#dcfce7;color:#15803d }
.wa-badge.online .dot { background:#16a34a;animation:pulse 2s infinite }
.wa-badge.offline { background:#fee2e2;color:#b91c1c }
.wa-badge.offline .dot { background:#dc2626 }
.wa-badge.unread-badge { background:#25D366;color:#fff;min-width:22px;justify-content:center }
@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.4} }
#roomsTbody tr:hover { background:#f0fdf4 }
</style>

<script>
let lastPollId = 0;
let qrAutoRetries = 0;
const QR_MAX_AUTO_RETRY = 3;

async function loadQr() {
    const box = document.getElementById('qrContainer');
    const btn = event?.currentTarget;
    const isAutoRetry = !btn && qrAutoRetries > 0;
    if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Memuat...'; }
    if (!isAutoRetry) qrAutoRetries = 0;
    box.innerHTML = '<p style="color:#64748b;font-size:.82rem"><i class="fas fa-spinner fa-spin"></i> Memuat QR... Fonnte sedang menyiapkan kode, mohon tunggu beberapa detik.</p>';
    try {
        const r = await fetch('{{ route("whatsapp.qr") }}', { headers: { 'Accept': 'application/json' } });
        // Tangani response non-JSON (mis. 500 halaman error) supaya tidak crash
        if (!r.ok && r.status !== 200) {
            let txt = '';
            try { txt = await r.text(); } catch(e) {}
            throw new Error('Server merespons HTTP ' + r.status + (txt ? ' (' + txt.substring(0,80) + ')' : ''));
        }
        const d = await r.json();

        // Kasus 1: device SUDAH terhubung → sembunyikan kartu QR
        if (d.connected) {
            qrAutoRetries = 0;
            const card = document.getElementById('qrCard');
            if (card) card.style.display = 'none';
            updateDeviceBadge(true);
            Swal && Swal.fire ? Swal.fire({icon:'success',title:'WhatsApp Terhubung',text:d.message||'Device sudah terhubung, QR tidak diperlukan.',timer:2500,showConfirmButton:false}) : alert(d.message || 'Device sudah terhubung');
            return;
        }

        // Kasus 2: QR berhasil didapat
        if (d.success && d.qr) {
            qrAutoRetries = 0;
            box.innerHTML = '<div id="qrImg" style="display:inline-block;padding:14px;background:#fff;border:1px solid #e2e8f0;border-radius:12px"></div>' +
                '<p style="font-size:.78rem;color:#64748b;margin-top:8px">' + (d.message || '') + '</p>' +
                '<p style="font-size:.72rem;color:#94a3b8;margin-top:4px"><i class="fas fa-info-circle"></i> QR bisa di-scan ulang tiap 1 menit bila belum tertautkan.</p>';
            if (window.QRCode) {
                new QRCode(document.getElementById('qrImg'), { text: d.qr, width: 220, height: 220 });
            } else {
                const s = document.createElement('script');
                s.src = 'https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.js';
                s.onload = () => new QRCode(document.getElementById('qrImg'), { text: d.qr, width: 220, height: 220 });
                document.body.appendChild(s);
            }
            return;
        }

        // Kasus 2b: QR masih dibuat Fonnte ("process") → auto-retry
        if (d.processing && qrAutoRetries < QR_MAX_AUTO_RETRY) {
            qrAutoRetries++;
            box.innerHTML = '<p style="color:#64748b;font-size:.82rem"><i class="fas fa-spinner fa-spin"></i> QR sedang dibuat di server Fonnte... percobaan ' + qrAutoRetries + '/' + QR_MAX_AUTO_RETRY + '</p>';
            setTimeout(loadQr, 4000);
            return;
        }

        // Kasus 3: gagal dengan pesan dari server
        qrAutoRetries = 0;
        box.innerHTML =
            '<div style="padding:14px 16px;background:#fef2f2;border:1px solid #fecaca;border-radius:10px;color:#991b1b;font-size:.82rem;text-align:left">' +
            '<i class="fas fa-times-circle"></i> <strong>Gagal memuat QR</strong><br>' +
            '<span style="font-size:.8rem">' + (d.message || 'Fonnte tidak dapat menghasilkan QR saat ini.') + '</span></div>' +
            '<div style="margin-top:10px;display:flex;gap:8px;justify-content:center;flex-wrap:wrap">' +
            '<button onclick="loadQr(this)" class="btn btn-primary btn-sm"><i class="fas fa-redo"></i> Coba Lagi</button>' +
            '<button onclick="checkDeviceStatus(this)" class="btn btn-secondary btn-sm"><i class="fas fa-plug"></i> Cek Status Device</button>' +
            '</div>';
    } catch (e) {
        qrAutoRetries = 0;
        box.innerHTML =
            '<div style="padding:14px 16px;background:#fef2f2;border:1px solid #fecaca;border-radius:10px;color:#991b1b;font-size:.82rem;text-align:left">' +
            '<i class="fas fa-exclamation-triangle"></i> <strong>Gagal menghubungi server</strong><br>' +
            '<span style="font-size:.8rem">' + e.message + '</span></div>' +
            '<button onclick="loadQr(this)" class="btn btn-primary btn-sm" style="margin-top:10px"><i class="fas fa-redo"></i> Coba Lagi</button>';
    } finally {
        if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-sync"></i> Refresh QR'; }
    }
}

/** Cek status device secara manual (tombol) */
async function checkDeviceStatus(btn) {
    const box = document.getElementById('qrContainer');
    if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Mengecek...'; }
    box.innerHTML = '<p style="color:#64748b;font-size:.82rem"><i class="fas fa-spinner fa-spin"></i> Mengecek status device...</p>';
    try {
        const r = await fetch('{{ route("whatsapp.device-status") }}', { headers: { 'Accept': 'application/json' } });
        const d = await r.json();
        if (d.connected) {
            updateDeviceBadge(true);
            const card = document.getElementById('qrCard');
            if (card) card.style.display = 'none';
            box.innerHTML = '<p style="color:#16a34a;font-size:.86rem"><i class="fas fa-check-circle"></i> <strong>Device terhubung!</strong> WhatsApp siap digunakan.</p>';
        } else {
            updateDeviceBadge(false);
            box.innerHTML = '<p style="color:#dc2626;font-size:.82rem"><i class="fas fa-times-circle"></i> Device belum terhubung. ' + (d.message || '') + '</p>' +
                '<button onclick="loadQr(this)" class="btn btn-primary btn-sm" style="margin-top:8px"><i class="fas fa-qrcode"></i> Tampilkan QR</button>';
        }
    } catch (e) {
        box.innerHTML = '<p style="color:#dc2626;font-size:.82rem">Gagal cek status: ' + e.message + '</p>';
    } finally {
        if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-plug"></i> Cek Status'; }
    }
}

/** Update badge device di header halaman */
function updateDeviceBadge(connected) {
    const badge = document.getElementById('deviceBadge');
    if (!badge) return;
    if (connected) {
        badge.className = 'wa-badge online';
        badge.innerHTML = '<span class="dot"></span> Terhubung';
    } else {
        badge.className = 'wa-badge offline';
        badge.innerHTML = '<span class="dot"></span> Terputus';
    }
}

async function pollRealtime() {
    try {
        const r = await fetch('{{ route("whatsapp.poll") }}?since_id=' + lastPollId);
        const d = await r.json();
        if (d.server_time) document.getElementById('serverTime').textContent = 'Update: ' + new Date(d.server_time).toLocaleTimeString();
        if (d.total_unread !== undefined) document.getElementById('totalUnread').textContent = d.total_unread + ' pesan belum dibaca';

        if (d.messages && d.messages.length > 0) {
            lastPollId = Math.max(lastPollId, ...d.messages.map(m => m.id));
            // Update badge unread (tanpa refresh halaman)
            if (d.total_unread > 0) {
                // notif halus di title
                if (document.title.indexOf('🔴') !== 0) document.title = '🔴 ' + document.title;
            } else {
                document.title = document.title.replace('🔴 ', '');
            }
        }
    } catch (e) {}
}

@if($enabled)
setInterval(pollRealtime, 5000); // polling tiap 5 detik
setTimeout(pollRealtime, 1000);
@endif
</script>
@endsection
